﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoppelOrderSystem.BusinessLayer
{
    internal class Order
	{
        	
        #region DATA Members
        private string orderNo;
		static int orderId = 0;
		private string orderStatus;
		private DateTime shipDate;
		private string shipAddress;
		private decimal grandTotal;
		private string handleBY;
		private DateTime create_date;

		public Order()
		{
			create_date = DateTime.Today;
			orderId++;
			orderNo = orderId + "";
			orderStatus = "Order Started";

		}

		#endregion

	}
}
