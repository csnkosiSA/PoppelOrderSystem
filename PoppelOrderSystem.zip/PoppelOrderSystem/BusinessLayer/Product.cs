﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoppelOrderSystem.BusinessLayer
{
    internal class Product
    {
        #region members 
        private string productID;
        private string productName;
        private string productCategory;
        private decimal productPrice;
        #endregion

        #region Constructor

        public Product(string productID, string productName, string productCategory, decimal productPrice)
        {
            this.ProductID = productID;
            this.ProductPrice = productPrice;
            this.ProductName = productName;
            this.ProductCategory = productCategory;
        }

        #endregion

        #region Property Methods
        public string ProductID
        {
            get { return productID; }
            set { productID = value; }
        }
        public string ProductName
        {
            get { return productName; }
            set
            {
                productName = value;
            }
        }
        public string ProductCategory
        {
            get { return productCategory; }
            set
            {
                productCategory = value;
            }
        }
        public decimal ProductPrice
        {
            get { return productPrice; }
            set
            {
                productPrice = value;
            }
        }

        #endregion
    }
}
