﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoppelOrderSystem.BusinessLayer
{
    internal class MarketingClerk:Person
    {
        #region data members
        string email;
        string address;
        string employee_ID;
        int years_working;

        #endregion
        #region Constructor

        public MarketingClerk(string email, string address, string Employee_ID, string name, string phone, string ID) : base()
        {
            this.email = email;
            this.address = address;
            this.employee_ID = Employee_ID;
            this.Name = name;
            this.ID = ID;
            this.Telephone = phone;
            this.years_working = 0;

        }

        #endregion
        #region Property Methods
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        public int Years_working
        {
            get { return years_working; }
            set
            {
                years_working = value;
            }
        }
        public string EmployeeID
        {
            get { return employee_ID; }
            set
            {
                employee_ID = value;
            }
        }

        #endregion


    }
}
